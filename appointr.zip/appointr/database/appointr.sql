-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 07, 2017 at 09:00 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `appointr`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts_faculty`
--

CREATE TABLE `accounts_faculty` (
  `user_id` int(6) NOT NULL,
  `departments` enum('CSE','ECE','MME','MTH','PHY','HSS') NOT NULL,
  `faculty_name` varchar(50) NOT NULL,
  `email_id` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `room_no` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `accounts_student`
--

CREATE TABLE `accounts_student` (
  `user_id` int(6) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `roll_no` varchar(8) NOT NULL,
  `email_id` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `appointment_request`
--

CREATE TABLE `appointment_request` (
  `request_id` int(6) NOT NULL,
  `faculty_id` int(6) NOT NULL,
  `student_id` int(6) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `reason` varchar(100) NOT NULL,
  `urgent` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `appointment_status`
--

CREATE TABLE `appointment_status` (
  `request_id` int(6) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `details` varchar(100) DEFAULT NULL,
  `modify_request` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts_faculty`
--
ALTER TABLE `accounts_faculty`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `accounts_student`
--
ALTER TABLE `accounts_student`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `roll_no` (`roll_no`);

--
-- Indexes for table `appointment_request`
--
ALTER TABLE `appointment_request`
  ADD PRIMARY KEY (`request_id`),
  ADD UNIQUE KEY `uq_1` (`faculty_id`,`student_id`),
  ADD KEY `fk_2` (`student_id`);

--
-- Indexes for table `appointment_status`
--
ALTER TABLE `appointment_status`
  ADD KEY `fk_3` (`request_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts_faculty`
--
ALTER TABLE `accounts_faculty`
  MODIFY `user_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1002;
--
-- AUTO_INCREMENT for table `accounts_student`
--
ALTER TABLE `accounts_student`
  MODIFY `user_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1002;
--
-- AUTO_INCREMENT for table `appointment_request`
--
ALTER TABLE `appointment_request`
  MODIFY `request_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1002;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment_request`
--
ALTER TABLE `appointment_request`
  ADD CONSTRAINT `fk_1` FOREIGN KEY (`faculty_id`) REFERENCES `accounts_faculty` (`user_id`),
  ADD CONSTRAINT `fk_2` FOREIGN KEY (`student_id`) REFERENCES `accounts_student` (`user_id`);

--
-- Constraints for table `appointment_status`
--
ALTER TABLE `appointment_status`
  ADD CONSTRAINT `fk_3` FOREIGN KEY (`request_id`) REFERENCES `appointment_request` (`request_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
