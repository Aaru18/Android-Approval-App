<?php
 

 
define('DB_USER', "collinx"); // db user
define('DB_PASSWORD', "shubham96"); // db password (mention db password here)
define('DB_DATABASE', "appointr"); // database name
define('DB_SERVER', "localhost"); // db server
?>