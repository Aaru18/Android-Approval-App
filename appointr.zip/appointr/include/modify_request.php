<?php

$response = array();

if (isset($_POST['id']) && isset($_POST['status']) && isset($_POST['modify'])) {
 
    $id = $_POST['id'];
    $status = $_POST['status'];
    $modify = $_POST['modify'];
    if ($modify){
        $date = $_POST['date'];
        $time = $_POST['time'];
    }     

    require_once __DIR__ . '/DbConnect.php';
    $db = new DB_CONNECT();
    
    if($modify){
        $query = sprintf("UPDATE appointment_request SET request_date = '%s', request_time  = '%s', status = 1, modify_request = 1 WHERE request_id = %d", mysql_real_escape_string($date), mysql_real_escape_string($time), mysql_real_escape_string($id));
    } else {
        $query = sprintf("UPDATE appointment_request SET status = 1 WHERE request_id = %d", mysql_real_escape_string($id));
    }
    $result = mysql_query($query);
    if($result){
    // success
    $response["success"] = 1;
    $response["message"] = "Successfully Accepted";
    // echoing JSON response
    echo json_encode($response);

    } else {
        $response["success"] = 0;
        $response["message"] = "Server Error";

        echo json_encode($response);
    }
   
    
} else {
    // required field is missing
    $response["success"] = 0;
    $response["message"] = "Required field(s) is missing";
 
    // echoing JSON response
    echo json_encode($response);
}
?>